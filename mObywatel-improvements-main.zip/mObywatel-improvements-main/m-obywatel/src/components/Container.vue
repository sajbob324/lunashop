<template>
  <ion-grid :fixed="true">
    <ion-row>
      <ion-col offset="1" size="10">
        <slot></slot>
      </ion-col>
    </ion-row>
  </ion-grid>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>